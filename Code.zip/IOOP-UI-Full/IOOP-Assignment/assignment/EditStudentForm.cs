using System;
using System.Drawing;
using System.Windows.Forms;

namespace assignment
{
    public class EditStudentForm : Form
    {
        private TextBox txtId, txtName, txtEmail, txtPhone, txtAddress, txtGender, txtModule, txtMonth;
        private ComboBox cboPayment;
        private Button btnSave, btnCancel;
        public Student Student { get; private set; }

        public EditStudentForm(Student s)
        {
            Student = s ?? new Student();
            InitializeComponent();
            LoadStudent();
        }

        private void InitializeComponent()
        {
            this.txtId = new TextBox();
            this.txtName = new TextBox();
            this.txtEmail = new TextBox();
            this.txtPhone = new TextBox();
            this.txtAddress = new TextBox();
            this.txtGender = new TextBox();
            this.txtModule = new TextBox();
            this.txtMonth = new TextBox();
            this.cboPayment = new ComboBox();
            this.btnSave = new Button();
            this.btnCancel = new Button();

            this.ClientSize = new Size(420, 330);
            int y = 10;
            void addLabel(string text, Control ctrl)
            {
                var lbl = new Label { Text = text, Location = new Point(10, y), Size = new Size(100, 20) };
                ctrl.Location = new Point(120, y);
                ctrl.Size = new Size(260, 20);
                this.Controls.Add(lbl);
                this.Controls.Add(ctrl);
                y += 30;
            }

            addLabel("Student ID", txtId);
            txtId.ReadOnly = true; // prevent changing primary id
            addLabel("Name", txtName);
            addLabel("Email", txtEmail);
            addLabel("Phone", txtPhone);
            addLabel("Address", txtAddress);
            addLabel("Gender", txtGender);
            addLabel("Module", txtModule);
            addLabel("Month", txtMonth);
            cboPayment.DropDownStyle = ComboBoxStyle.DropDownList;
            cboPayment.Items.AddRange(new object[] { "Unpaid", "Paid" });
            addLabel("Payment Status", cboPayment);

            btnSave.Text = "Save"; btnSave.Location = new Point(120, y); btnSave.Click += BtnSave_Click;
            btnCancel.Text = "Cancel"; btnCancel.Location = new Point(220, y); btnCancel.Click += (s, e) => this.Close();
            this.Controls.Add(btnSave); this.Controls.Add(btnCancel);
        }

        private void LoadStudent()
        {
            txtId.Text = Student.StudentId ?? string.Empty;
            txtName.Text = Student.Name ?? string.Empty;
            txtEmail.Text = Student.Email ?? string.Empty;
            txtPhone.Text = Student.Phone ?? string.Empty;
            txtAddress.Text = Student.Address ?? string.Empty;
            txtGender.Text = Student.Gender ?? string.Empty;
            txtModule.Text = Student.Module ?? string.Empty;
            txtMonth.Text = Student.Month ?? string.Empty;
            cboPayment.SelectedItem = Student.PaymentStatus ?? "Unpaid";
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            Student.Name = txtName.Text.Trim();
            Student.Email = txtEmail.Text.Trim();
            Student.Phone = txtPhone.Text.Trim();
            Student.Address = txtAddress.Text.Trim();
            Student.Gender = txtGender.Text.Trim();
            Student.Module = txtModule.Text.Trim();
            Student.Month = txtMonth.Text.Trim();
            Student.PaymentStatus = cboPayment.SelectedItem as string ?? "Unpaid";

            StudentStore.Update(Student);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
