using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace assignment
{
    public class PayStudentForm : Form
    {
        private ComboBox cboStudents;
        private Label lblAmount;
        private Button btnPay;
        private Button btnClose;

        public PayStudentForm()
        {
            InitializeComponent();
            LoadStudents();
        }

        private void InitializeComponent()
        {
            this.cboStudents = new ComboBox();
            this.lblAmount = new Label();
            this.btnPay = new Button();
            this.btnClose = new Button();
            this.SuspendLayout();

            this.cboStudents.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cboStudents.Location = new Point(12, 12);
            this.cboStudents.Size = new Size(300, 24);
            this.cboStudents.SelectedIndexChanged += CboStudents_SelectedIndexChanged;

            this.lblAmount.Location = new Point(12, 50);
            this.lblAmount.Size = new Size(300, 23);
            this.lblAmount.Text = "Payment amount: $0";

            this.btnPay.Location = new Point(12, 80);
            this.btnPay.Size = new Size(90, 30);
            this.btnPay.Text = "Mark Paid";
            this.btnPay.Click += BtnPay_Click;

            this.btnClose.Location = new Point(120, 80);
            this.btnClose.Size = new Size(90, 30);
            this.btnClose.Text = "Close";
            this.btnClose.Click += (s, e) => this.Close();

            this.ClientSize = new Size(340, 130);
            this.Controls.Add(this.cboStudents);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.btnClose);
            this.Text = "Pay Student";
            this.ResumeLayout(false);
        }

        private void LoadStudents()
        {
            cboStudents.Items.Clear();
            foreach (var s in StudentStore.GetAll())
            {
                cboStudents.Items.Add(new ComboBoxItem(s.Name + " (" + s.StudentId + ")", s.StudentId));
            }
            if (cboStudents.Items.Count > 0) cboStudents.SelectedIndex = 0;
        }

        private void CboStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            // For demo, set amount based on module or fixed
            lblAmount.Text = "Payment amount: $100";
        }

        private void BtnPay_Click(object sender, EventArgs e)
        {
            if (!(cboStudents.SelectedItem is ComboBoxItem item) || string.IsNullOrEmpty(item.Value)) return;
            var id = item.Value;
            var students = StudentStore.GetAll();
            var s = students.Find(x => string.Equals(x.StudentId, id, StringComparison.OrdinalIgnoreCase));
            if (s == null) return;
            s.PaymentStatus = "Paid";
            s.PaymentDate = DateTime.Now;
            StudentStore.Update(s);
            MessageBox.Show("Payment recorded.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadStudents();
        }
    }
}
