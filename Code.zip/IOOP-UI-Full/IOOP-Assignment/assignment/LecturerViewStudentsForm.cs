﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment
{
    public partial class LecturerViewStudentsForm : Form
    {
        public LecturerViewStudentsForm()
        {
            InitializeComponent();
            LoadStudents();
            try
            {
                if (this.Controls.ContainsKey("dataGridView1"))
                {
                    var grid = this.Controls["dataGridView1"] as DataGridView;
                    if (grid != null)
                    {
                        grid.CellDoubleClick += Grid_CellDoubleClick;
                    }
                }
            }
            catch { }
            // add toolbar buttons programmatically
            try
            {
                var btnAdd = new Button { Text = "Add", Location = new System.Drawing.Point(420, 10), Size = new System.Drawing.Size(75, 24) };
                var btnEdit = new Button { Text = "Edit", Location = new System.Drawing.Point(500, 10), Size = new System.Drawing.Size(75, 24) };
                var btnDelete = new Button { Text = "Delete", Location = new System.Drawing.Point(580, 10), Size = new System.Drawing.Size(75, 24) };
                var btnViewSchedule = new Button { Text = "View Schedule", Location = new System.Drawing.Point(660, 10), Size = new System.Drawing.Size(100, 24) };
                var btnRefresh = new Button { Text = "Refresh", Location = new System.Drawing.Point(770, 10), Size = new System.Drawing.Size(75, 24) };

                this.Controls.Add(btnAdd);
                this.Controls.Add(btnEdit);
                this.Controls.Add(btnDelete);
                this.Controls.Add(btnViewSchedule);
                this.Controls.Add(btnRefresh);

                btnAdd.Click += (s, e) => {
                    // open register student form hosted
                    var uc = new RegisterStudentForm();
                    var host = new Form();
                    host.Text = "Register Student";
                    host.ClientSize = uc.Size;
                    uc.Dock = DockStyle.Fill;
                    host.Controls.Add(uc);
                    host.ShowDialog(this);
                    LoadStudents();
                };

                btnEdit.Click += (s, e) => {
                    if (!this.Controls.ContainsKey("dataGridView1")) return;
                    var grid = this.Controls["dataGridView1"] as DataGridView;
                    if (grid == null || grid.SelectedRows.Count == 0) { MessageBox.Show("Select a student to edit.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                    var id = grid.SelectedRows[0].Cells[0].Value as string;
                    var st = StudentStore.GetAll().Find(x => string.Equals(x.StudentId, id, StringComparison.OrdinalIgnoreCase));
                    if (st == null) return;
                    var ed = new EditStudentForm(st);
                    if (ed.ShowDialog(this) == DialogResult.OK) LoadStudents();
                };

                btnDelete.Click += (s, e) => {
                    if (!this.Controls.ContainsKey("dataGridView1")) return;
                    var grid = this.Controls["dataGridView1"] as DataGridView;
                    if (grid == null || grid.SelectedRows.Count == 0) { MessageBox.Show("Select a student to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                    var id = grid.SelectedRows[0].Cells[0].Value as string;
                    var ok = MessageBox.Show("Delete selected student?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (ok == DialogResult.Yes) { StudentStore.RemoveById(id); LoadStudents(); }
                };

                btnViewSchedule.Click += (s, e) => {
                    if (!this.Controls.ContainsKey("dataGridView1")) return;
                    var grid = this.Controls["dataGridView1"] as DataGridView;
                    if (grid == null || grid.SelectedRows.Count == 0) { MessageBox.Show("Select a student to view schedule.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                    var id = grid.SelectedRows[0].Cells[0].Value as string;
                    var st = StudentStore.GetAll().Find(x => string.Equals(x.StudentId, id, StringComparison.OrdinalIgnoreCase));
                    var view = new ViewScheduleForm();
                    view.ClearSchedule();
                    view.SetStudentId(id);
                    // Populate sample schedule rows based on Module
                    var trainer = TrainerStore.GetAll().Count > 0 ? TrainerStore.GetAll()[0] : null;
                    var lecturerName = trainer != null ? (string.IsNullOrEmpty(trainer.Name) ? trainer.Username : trainer.Name) : "TBA";
                    var module = st != null && !string.IsNullOrEmpty(st.Module) ? st.Module : "Module A";
                    view.AddScheduleRow(module + "-1", module + " Lecture 1", "Mon 10:00-12:00", lecturerName);
                    view.AddScheduleRow(module + "-2", module + " Lecture 2", "Wed 10:00-12:00", lecturerName);
                    view.AddScheduleRow(module + "-3", module + " Tutorial", "Fri 14:00-15:30", lecturerName);
                    view.ShowDialog(this);
                };

                btnRefresh.Click += (s, e) => LoadStudents();
            }
            catch { }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Grid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var grid = sender as DataGridView;
                if (grid == null || grid.SelectedRows.Count == 0) return;
                var id = grid.SelectedRows[0].Cells[0].Value as string;
                if (string.IsNullOrEmpty(id)) return;
                var st = StudentStore.GetAll().Find(x => string.Equals(x.StudentId, id, StringComparison.OrdinalIgnoreCase));
                if (st == null) return;
                var ed = new EditStudentForm(st);
                if (ed.ShowDialog(this) == DialogResult.OK)
                {
                    LoadStudents();
                }
            }
            catch { }
        }

        private void LoadStudents()
        {
            // If designer grid exists, bind to StudentStore
            try
            {
                if (this.Controls.ContainsKey("dataGridView1"))
                {
                    var grid = this.Controls["dataGridView1"] as DataGridView;
                    if (grid != null)
                    {
                        var dt = new DataTable();
                        dt.Columns.Add("StudentId", typeof(string));
                        dt.Columns.Add("Name", typeof(string));
                        dt.Columns.Add("Phone", typeof(string));
                        dt.Columns.Add("Email", typeof(string));
                        dt.Columns.Add("Address", typeof(string));
                        dt.Columns.Add("Gender", typeof(string));
                        dt.Columns.Add("PaymentStatus", typeof(string));
                        var students = StudentStore.GetAll();
                        if (students.Count == 0)
                        {
                            dt.Rows.Add("S001", "Alice Smith", "0123456789", "alice@example.com", "123 Main St", "Female", "Paid");
                        }
                        else
                        {
                            foreach (var s in students)
                            {
                                dt.Rows.Add(s.StudentId, s.Name, s.Phone, s.Email, s.Address, s.Gender, s.PaymentStatus);
                            }
                        }
                        grid.DataSource = dt;
                    }
                }
            }
            catch { }
        }
    }
}
