﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment
{
    public partial class ViewIncomeReportForm : Form
    {
        public ViewIncomeReportForm()
        {
            InitializeComponent();
            LoadTrainers();
            comboBox1.SelectedIndex = DateTime.Now.Month - 1;
            this.button1.Click += Button1_Click;
            this.button2.Click += (s, e) => this.Close();
        }

        private void LoadTrainers()
        {
            comboBox2.Items.Clear();
            comboBox2.Items.Add("All");
            foreach (var t in TrainerStore.GetAll())
            {
                var name = string.IsNullOrEmpty(t.Name) ? t.Username : t.Name;
                comboBox2.Items.Add(new ComboBoxItem(name + " (" + t.Username + ")", t.Id));
            }
            comboBox2.SelectedIndex = 0;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            // Compute report for selected month and trainer
            var monthIndex = comboBox1.SelectedIndex; // 0-based
            if (monthIndex < 0) monthIndex = DateTime.Now.Month - 1;
            var year = DateTime.Now.Year;
            var month = monthIndex + 1;

            string selectedTrainerId = null;
            if (comboBox2.SelectedItem is ComboBoxItem cbi)
                selectedTrainerId = cbi.Value;

            // Build aggregation: group by trainer name + module
            var report = new System.Collections.Generic.Dictionary<string, (int count, decimal income)>();

            // For simplicity, assume each paid student contributes 100
            const decimal perStudentAmount = 100m;

            foreach (var s in StudentStore.GetAll())
            {
                if (s.PaymentStatus != "Paid" || !s.PaymentDate.HasValue) continue;
                if (s.PaymentDate.Value.Year != year || s.PaymentDate.Value.Month != month) continue;

                // If a trainer filter is selected, we can't reliably map students to trainer without a linking table.
                // We'll include all students when "All" is selected. If a specific trainer is selected, include only students whose Module matches trainer's Module (best-effort)
                if (!string.IsNullOrEmpty(selectedTrainerId))
                {
                    var tr = TrainerStore.GetAll().Find(t => t.Id == selectedTrainerId);
                    if (tr != null)
                    {
                        // best-effort: include student if module contains trainer username or student has no module assigned
                        if (!string.IsNullOrEmpty(s.Module) && !s.Module.ToLowerInvariant().Contains((tr.Username ?? string.Empty).ToLowerInvariant()))
                            continue;
                    }
                }

                var trainerName = "Unknown";
                if (!string.IsNullOrEmpty(s.Module)) trainerName = s.Module; // group by module as proxy

                if (!report.ContainsKey(trainerName)) report[trainerName] = (0, 0m);
                var cur = report[trainerName];
                cur.count += 1;
                cur.income += perStudentAmount;
                report[trainerName] = cur;
            }

            // Populate grid
            dataGridView1.Rows.Clear();
            foreach (var kv in report)
            {
                dataGridView1.Rows.Add(kv.Key, kv.Key, kv.Value.count, kv.Value.income);
            }
        }
    }
}
